package com.example.flutter_application_1_connect_server

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
